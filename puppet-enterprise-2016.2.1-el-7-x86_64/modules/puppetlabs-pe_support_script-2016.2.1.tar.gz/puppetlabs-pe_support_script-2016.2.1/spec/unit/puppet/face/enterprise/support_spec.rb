require 'spec_helper'
require 'puppet/face'

describe "Puppet::Face[:enterprise, :current]" do
  let(:enterprise) { Puppet::Face[:enterprise, :current] }

  context "support action" do
  end
end

