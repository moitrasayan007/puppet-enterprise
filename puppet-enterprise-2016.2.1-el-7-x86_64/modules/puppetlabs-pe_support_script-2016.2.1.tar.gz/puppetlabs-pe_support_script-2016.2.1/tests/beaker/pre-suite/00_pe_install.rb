test_name 'PE-15434 - - Install Puppet Enterprise' do
  step 'Install PE' do
    install_pe
  end
end
