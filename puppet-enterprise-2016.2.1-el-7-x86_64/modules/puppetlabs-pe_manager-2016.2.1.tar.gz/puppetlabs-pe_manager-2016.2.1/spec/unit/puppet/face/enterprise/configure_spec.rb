require 'spec_helper'
require 'puppet/face'

# Cribbed from Puppet spec/lib/puppet_spec/matchers.rb
RSpec::Matchers.define :exit_with do |expected|
  actual = nil
  match do |block|
    begin
      block.call
    rescue SystemExit => e
      actual = e.status
    end
    actual and actual == expected
  end

  supports_block_expectations

  failure_message do |block|
    "expected exit with code #{expected} but " +
      (actual.nil? ? " exit was not called" : "we exited with #{actual} instead")
  end

  failure_message_when_negated do |block|
    "expected that exit would not be called with #{expected}"
  end

  description do
    "expect exit with #{expected}"
  end
end

describe "Puppet::Face[:enterprise, :current]" do
  let(:enterprise) { Puppet::Face[:enterprise, :current] }
  let(:tmpdir) { Dir.mktmpdir("tmp") }
  let(:state_dir) { "#{tmpdir}/var/state" }

  context "configure action" do
    let(:execute) { ['--execute', 'notice("ran")'] }

    before(:each) do
      FileUtils.mkdir_p(state_dir)
      FileUtils.mkdir_p("#{tmpdir}/code")
      FileUtils.mkdir_p("#{tmpdir}/etc")
      FileUtils.mkdir_p("#{tmpdir}/run")
      FileUtils.mkdir_p("#{tmpdir}/log")
      Puppet[:vardir] = "#{tmpdir}/var" 
      Puppet[:codedir] = "#{tmpdir}/code"
      Puppet[:confdir] = "#{tmpdir}/etc"
      Puppet[:rundir] = "#{tmpdir}/run"
      Puppet[:logdir] = "#{tmpdir}/log"
      # Cleans up log errors around Puppet managing the above basedirs (vardir, codedir, etc.)
      Puppet[:user] = ENV['USER']
      Puppet::Parser::Functions.reset
    end

    after(:each) do
      FileUtils.rm_rf tmpdir, :secure => true
      # lockfile is an instance variable on the Puppet::Face[:enterprise,
      # :current] class instance which is cached in a
      # Puppet::Interface::FaceCollection and only loaded once.  There isn't an
      # explicit clear or unload for this collection, and the lockfile_path
      # will alter between tests, so we need to clear these manually.
      enterprise.instance_variable_set(:@lockfile_path, nil)
      enterprise.instance_variable_set(:@lockfile, nil)
    end

    def expect_configure_with(exitcode, log_message, args = {})
      # do not include 'pe_install' class so we are just testing the face, not the modules
      allow(enterprise).to receive(:default_arguments) { execute }

      logs = []
      # Provide 'production' as current_environment so that configurer doesn't
      # switch from 'production' to '*root*' since we are jumping into the face
      # without a full initialization
      env = Puppet::Node::Environment.create(:production, [], '')
      Puppet.override(:current_environment => env) do
        Puppet::Util::Log.with_destination(Puppet::Test::LogCollector.new(logs)) do
          expect { enterprise.configure(args) }.to exit_with(exitcode)
        end
      end
      expect(logs.map { |l| l.message }).to include(log_message)
    end

    it "configures" do
      expect_configure_with(0, 'ran')
    end

    it "exits 17 if puppet lockfile is in place" do
      lockfile = instance_double(Puppet::Util::Pidlock)
      expect(lockfile).to receive(:lock).and_raise(Puppet::LockError, 'locked')
      allow(enterprise).to receive(:lockfile) { lockfile }

      expect_configure_with(17, %r{Puppet run already in progress.*#{Puppet[:agent_catalog_run_lockfile]}})
    end

    context "with --debug flag" do
      let(:execute) { ['--execute', 'notify { "ran debug": loglevel => debug }'] }

      before(:each) do
        # simulate the --debug flag being caught by appication opt parsing:
        # https://github.com/puppetlabs/puppet/blob/4.4.0/lib/puppet/application/face_base.rb#L8
        Puppet.debug = true
      end

      it "configures and emits debug logs" do
        expect_configure_with(0, 'ran debug')
      end
    end

    context "with --detailed-exitcodes flag" do
      let(:execute) { ['--execute', 'notify { "should exit 2": }'] }

      it "configures and returns 2 for changes" do
        expect_configure_with(2, 'should exit 2', {:detailed_exitcodes => true })
      end
    end
  end
end
