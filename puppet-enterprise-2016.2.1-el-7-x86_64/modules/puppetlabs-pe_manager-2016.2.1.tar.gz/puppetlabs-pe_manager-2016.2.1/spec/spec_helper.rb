require 'puppetlabs_spec_helper/module_spec_helper'
require 'rspec-puppet-facts'
include RspecPuppetFacts

RSpec.configure do |config|
  # Re-override the mock_with :mocha that is in
  # puppetlabs_spec_helper-1.1.1/lib/puppetlabs_spec_helper/puppet_spec_helper.rb:122
  config.mock_with :rspec
end
