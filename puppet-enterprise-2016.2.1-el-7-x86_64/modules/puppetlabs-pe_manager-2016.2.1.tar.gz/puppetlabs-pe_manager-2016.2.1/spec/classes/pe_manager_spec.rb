require 'spec_helper'

describe 'pe_manager' do
  context 'supported operating systems' do
    on_supported_os.each do |os, facts|
      context "on #{os}" do
        let(:facts) do
          facts
        end

        it { is_expected.to compile.with_all_deps }
        it do
          is_expected.to contain_file('/opt/puppetlabs/server/apps/enterprise')
            .with_ensure('directory')
            .with_mode('0755')
            .with_before(['File[/opt/puppetlabs/server/apps/enterprise/bin]'])
        end
        it do
          is_expected.to contain_file('/opt/puppetlabs/server/apps/enterprise/bin')
            .with_ensure('directory')
            .with_mode('0755')
            .with_before(['File[/opt/puppetlabs/server/apps/enterprise/bin/puppet-enterprise]'])
        end
        it do
          is_expected.to contain_file('/opt/puppetlabs/server/apps/enterprise/bin/puppet-enterprise')
            .with_ensure('file')
            .with_mode('0755')
            .with_source('puppet:///modules/pe_manager/puppet-enterprise')
        end
        it do
          is_expected.to contain_file('/opt/puppetlabs/bin/puppet-enterprise')
            .with_ensure('link')
            .with_target('/opt/puppetlabs/server/apps/enterprise/bin/puppet-enterprise')
        end
      end
    end
  end
end
