require 'puppet/indirector/face'
require 'puppet/application/apply'
require 'puppet/util/command_line'
require 'puppet/agent'
require 'puppet/agent/locker'
require 'puppet/error'

# The initial version of the face is based of Reid Vandewiele's nimbus
# module's latest version, which is 0.7.0.
#
# https://github.com/puppetlabs/tse-module-nimbus/releases/tag/0.7.0
Puppet::Face.define(:enterprise, '1.0.0') do
  extend Puppet::Agent::Locker

  action :configure do
    summary "Configure the local system using given Puppet all-in-one configuration file(s)."
    description <<-EOT
      Configure the local system using given Puppet all-in-one configuration file(s).

      Will exit (17) if another puppet run is already in progress.
    EOT
    when_invoked do |options|
      begin
        lock do
          puppet_enterprise_context do
            ensure_meep_load_path(Puppet.lookup(:current_environment))

            argv = default_arguments
            argv << '--detailed-exitcodes' if options[:detailed_exitcodes]
            command_line = Puppet::Util::CommandLine.new('puppet', argv)
            apply = Puppet::Application::Apply.new(command_line)
            apply.parse_options
            Puppet::Util::Log.close(:console)
            apply.run_command
          end
        end
      rescue Puppet::LockError
        Puppet.notice "Puppet run already in progress; aborting  (#{lockfile_path} exists)"
        exit(17)
      end
    end

    option("--detailed-exitcodes") do
      summary "Provide extra information about the run via exit codes"
      description <<-EOT
        Provide extra information about the run via exit codes. If enabled, 'puppet
        enterprise configure' will use the following exit codes:

        0: The run succeeded with no changes or failures; the system was already in
        the desired state.

        1: The run failed.

        2: The run succeeded, and some resources were changed.

        4: The run succeeded, and some resources failed.

        6: The run succeeded, and included both changes and failures.
      EOT
    end
  end

  def puppet_enterprise_context(user_arguments = [], &block)
    Puppet[:node_terminus]         = 'plain'
    Puppet[:data_binding_terminus] = 'hiera'
    Puppet[:default_file_terminus] = 'file_server'
    Puppet[:modulepath] = default_modulepath
    Puppet[:hiera_config] = '/etc/puppetlabs/enterprise/hiera.yaml'

    environment_name = Puppet[:environment]

    loader = Puppet::Environments::StaticPrivate.new(
      Puppet::Node::Environment.create(environment_name,
                                       [default_modulepath],
                                       Puppet::Node::Environment::NO_MANIFEST)
    )

    environment = loader.get(environment_name)

    Puppet.override(
      :environments => loader,
      :current_environment => environment
    ) do
      block.call
    end
  end

  def default_arguments
    [
      '--execute', 'include pe_install',
      '--logdest', 'timestamped_console',
    ]
  end

  def default_modulepath
    '/opt/puppetlabs/server/data/enterprise/modules'
  end

  # This method just ensures we have a working LOAD_PATH just in case the initial
  # modulepath pointed to a directory which contained pe_manager, but not the rest
  # of the pe modules needed for meep to function.
  def ensure_meep_load_path(env)
    env.each_plugin_directory do |dir|
      $LOAD_PATH << dir unless $LOAD_PATH.include?(dir)
    end
  end
end
