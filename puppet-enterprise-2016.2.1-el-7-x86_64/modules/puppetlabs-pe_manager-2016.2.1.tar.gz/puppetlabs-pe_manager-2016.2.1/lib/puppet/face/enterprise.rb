require 'puppet/indirector/face'
require 'puppet_x/pem/log/destinations.rb'

Puppet::Face.define(:enterprise, '1.0.0') do
  copyright "Puppet Labs", 2015
  license   "Puppet Enterprise Software License Agreement"

  summary "Manage configuration of Puppet Enterprise."
  description <<-'EOT'
    This subcommand uses Puppet to configure state on the local system using a
    standalone Puppet environment, with all classification,
    data bindings, and modules (code) specified in a unified input.
  EOT

  action :help do
    default
    summary "Display help about the enterprise subcommand."
    when_invoked do |*args|
      Puppet::Face[:help, '0.0.1'].help('enterprise')
    end
  end
end
