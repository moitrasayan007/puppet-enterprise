require 'puppet_x/pem/config'
require 'puppet/indirector/plain'

class Puppet::Node::Enterprise < Puppet::Indirector::Plain
  desc "node terminus for use with the enterprise face."

  def find(request)
    node = Puppet::Node.new(request.key)
    node.classes = PuppetX::Pem::Config[:classes]
    node.parameters = PuppetX::Pem::Config[:variables]
    node.fact_merge
    node
  end
end
