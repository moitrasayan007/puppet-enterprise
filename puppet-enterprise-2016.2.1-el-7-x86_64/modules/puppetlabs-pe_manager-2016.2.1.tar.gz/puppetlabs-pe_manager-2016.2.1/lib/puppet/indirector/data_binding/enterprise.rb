require 'puppet/indirector/terminus'
require 'puppet_x/pem/config'

class Puppet::DataBinding::Enterprise < Puppet::Indirector::Plain

  desc "data_binding terminus for use with Enterprise face."

  def find(request)
    data[request.key] || nil
  end

  def data
    @data ||= PuppetX::Pem::Config[:data]
  end
end
