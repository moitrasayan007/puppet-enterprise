require 'securerandom'

module Puppet::Parser::Functions
  newfunction(:generate_password, :type => :rvalue) do |args|
    string_length = args[0] ? args[0].to_i : 16
    SecureRandom.urlsafe_base64(string_length)
  end
end
