require 'socket'
require 'timeout'

module Puppet::Parser::Functions
  newfunction(:is_port_open, :type => :rvalue, :arity => 2) do |args|
    host = args[0]
    port = args[1]

    begin
      Timeout::timeout(10) do
        begin
          s = TCPSocket.new(host, port)
          s.close
          return true
        rescue Errno::ECONNREFUSED, Errno::EHOSTUNREACH
          return false
        rescue SocketError, IOError, SystemCallError => e
          info("While testing for an open port at #{host}:#{port}, received #{e.class} '#{e}' error")
          return false
        end
      end
    rescue Timeout::Error
      return false
    end
  end
end
