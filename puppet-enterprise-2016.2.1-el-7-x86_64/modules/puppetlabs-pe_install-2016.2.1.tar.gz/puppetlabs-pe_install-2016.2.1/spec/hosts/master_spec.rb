require 'spec_helper'

RSpec.shared_examples 'a base run on the master node' do
  it { is_expected.to compile.with_all_deps }
  it { is_expected.to contain_class('puppet_enterprise::profile::certificate_authority') }
  it { is_expected.to contain_class('puppet_enterprise::profile::master') }
  it { is_expected.to contain_class('puppet_enterprise::profile::orchestrator') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::database') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::puppetdb') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::console') }
  it { is_expected.to contain_class('puppet_enterprise::profile::mcollective::peadmin') }
  it do
    # mcollective server is not installed in split by meep at the moment, due to
    # stomp_password not being part of classification
    is_expected.to_not contain_class('puppet_enterprise::profile::mcollective::agent')
  end
  it { is_expected.to contain_class('puppet_enterprise::profile::amq::broker') }
  it { is_expected.to contain_class('puppet_enterprise::profile::agent') }
  it { is_expected.to contain_class("pe_repo::platform::#{platform_class}") }
  it do
    is_expected.to(have_a_resource('Class[Puppet_enterprise::Packages]')
                   .that_is_a_dependency_for_downstream_resources(
                     'Class[Puppet_enterprise::Profile::Certificate_authority]',
                     'Class[Puppet_enterprise::Profile::Master]',
                     'Class[Puppet_enterprise::Profile::Amq::Broker]',
                     'Class[Puppet_enterprise::Profile::Orchestrator]',
                     'Class[Puppet_enterprise::Profile::Agent]',
                   ))
  end
  it { is_expected.to contain_package('postgresql-client')
        .with_ensure('latest')
        .with_name('pe-postgresql') }

  it { is_expected.not_to have_a_resource('Exec[set console admin password]') }
end

describe 'master host' do
  context 'supported operating systems' do
    on_filtered_os(:redhat, :debian, :sles).each do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:node) { 'master.rspec' }
        let(:layout) { 'split' }

        include_examples 'a base run on the master node'

        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-orchestration-services before install]') }
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-puppetserver before install]') }
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-activemq before install]') }
        it { is_expected.to have_a_resource('File[default site.pp]') }

        context 'when upgrading' do
          let(:context_facts) do
            {
              :pe_server_version => '2016.1.2',
            }
          end

          include_examples 'a base run on the master node'

          it { is_expected.to_not have_a_resource('File[default site.pp]') }
          it { is_expected.to have_a_resource('Exec[Shutdown pe-orchestration-services before install]')
                .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
          it { is_expected.to have_a_resource('Exec[Shutdown pe-puppetserver before install]')
                .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
          it { is_expected.to have_a_resource('Exec[Shutdown pe-activemq before install]')
                .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
        end

        context 'set code_manager_auto_configure' do
          let(:node) { 'masterofmasters.rspec' }
          let(:pe_conf) do
            <<-HIERA
puppet_enterprise::certificate_authority_host: "#{node}"
puppet_enterprise::puppet_master_host: "#{node}"
puppet_enterprise::console_host: 'console.rspec'
puppet_enterprise::puppetdb_host: 'puppetdb.rspec'
puppet_enterprise::database_host: 'puppetdb.rspec'
puppet_enterprise::mcollective_middleware_hosts: ["#{node}"]
puppet_enterprise::pcp_broker_host: "#{node}"
puppet_enterprise::profile::master::code_manager_auto_configure: true
            HIERA
          end

          around(:each) do |example|
            run_with_custom_pe_conf(node, pe_conf, example)
          end

          it do
            is_expected.to contain_pe_hocon_setting('file-sync.repos.puppet-code.staging-dir')
              .with_setting('file-sync.repos.puppet-code.staging-dir')
              .with_value('/etc/puppetlabs/code-staging')
              .with_ensure('present')
          end
          it do
            is_expected.to contain_pe_puppet_authorization__rule('puppetlabs file sync repo')
              .with_match_request_path('/file-sync-git/')
              .with_ensure('present')
          end
          it { is_expected.to contain_pe_concat__fragment('puppetserver file-sync-storage-service') }
          it { is_expected.to contain_pe_concat__fragment('puppetserver file-sync-versioned-code-service') }
          it { is_expected.to_not contain_exec(anything).with_command(%r{rm.*/etc/puppetlabs/code}) }
        end
      end
    end
  end
end
