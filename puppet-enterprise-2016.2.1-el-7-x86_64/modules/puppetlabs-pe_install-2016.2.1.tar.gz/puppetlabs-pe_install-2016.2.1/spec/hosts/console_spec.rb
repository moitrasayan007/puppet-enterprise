require 'spec_helper'

RSpec.shared_examples 'a base run on the console node' do
  it { is_expected.to compile.with_all_deps }
  it { is_expected.to contain_class('puppet_enterprise::profile::console') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::master') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::puppetdb') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::database') }
  it do
    # mcollective server is not installed in split by meep at the moment, due to
    # stomp_password not being part of classification
    is_expected.to_not contain_class('puppet_enterprise::profile::mcollective::agent')
  end
  it { is_expected.to contain_class('puppet_enterprise::profile::agent') }
  it do
    is_expected.to(have_a_resource('Class[Puppet_enterprise::Packages]')
                   .that_is_a_dependency_for_downstream_resources(
                     'Class[Puppet_enterprise::Profile::Console]',
                     'Class[Puppet_enterprise::Profile::Agent]',
                   ))
  end
  it { is_expected.to contain_package('postgresql-client')
        .with_ensure('latest')
        .with_name('pe-postgresql') }

  # The password string is shell escaped, so we must NOT quote it.
  it { is_expected.to contain_exec('set console admin password')
      .with_command(/set_console_admin_password.rb \\~puppetlab\\'s/) }
end

describe 'console host' do
  context 'supported operating systems' do
    on_filtered_os(:redhat, :debian, :sles) do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:node) { 'console.rspec' }
        let(:layout) { 'split' }

        include_examples 'a base run on the console node'
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-console-services before install]') }
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-nginx before install]') }

        context 'when upgrading' do
          let(:context_facts) do
            {
              :pe_server_version => '2016.1.2',
            }
          end

          include_examples 'a base run on the console node'
          it { is_expected.to have_a_resource('Exec[Shutdown pe-console-services before install]')
                .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
          it { is_expected.to have_a_resource('Exec[Shutdown pe-nginx before install]')
              .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
        end
      end
    end
  end
end
