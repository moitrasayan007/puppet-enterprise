require 'spec_helper'

RSpec.shared_examples 'a base run on the puppetdb node' do
  it { is_expected.to compile.with_all_deps }
  it { is_expected.to contain_class('puppet_enterprise::profile::puppetdb') }
  it { is_expected.to contain_class('puppet_enterprise::profile::database') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::master') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::console') }
  it do
    # mcollective server is not installed in split by meep at the moment, due to
    # stomp_password not being part of classification
    is_expected.to_not contain_class('puppet_enterprise::profile::mcollective::agent')
  end
  it { is_expected.to contain_class('puppet_enterprise::profile::agent') }
  it do
    is_expected.to(have_a_resource('Class[Puppet_enterprise::Packages]')
                   .that_is_a_dependency_for_downstream_resources(
                     'Class[Puppet_enterprise::Profile::Puppetdb]',
                     'Class[Puppet_enterprise::Profile::Agent]',
                   ))
  end

  it { is_expected.not_to have_a_resource('Exec[set console admin password]') }
end

describe 'puppetdb host' do
  context 'supported operating systems' do
    on_filtered_os(:redhat, :debian) do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:node) { 'puppetdb.rspec' }
        let(:layout) { 'split' }

        include_examples 'a base run on the puppetdb node'
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-puppetdb before install]') }

        context 'when upgrading' do
          let(:context_facts) do
            {
              :pe_server_version => '2016.1.2',
            }
          end

          include_examples 'a base run on the puppetdb node'
          it { is_expected.to have_a_resource('Exec[Shutdown pe-puppetdb before install]')
                .that_is_a_dependency_for_a_downstream('Class[Puppet_enterprise::Packages]') }
        end
      end
    end
  end
end
