require 'spec_helper'

RSpec.shared_examples 'a base run on the database node' do
  it { is_expected.to compile.with_all_deps }
  it { is_expected.to contain_class('puppet_enterprise::profile::database') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::master') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::puppetdb') }
  it { is_expected.to_not contain_class('puppet_enterprise::profile::console') }
  it do
    # mcollective server is not installed in split by meep at the moment, due to
    # stomp_password not being part of classification
    is_expected.to_not contain_class('puppet_enterprise::profile::mcollective::agent')
  end
  it { is_expected.to contain_class('puppet_enterprise::profile::agent') }
  it { is_expected.to contain_class('puppet_enterprise::profile::database').that_requires('Package[postgresql-server]') }
  it { is_expected.to contain_package('postgresql-client')
        .with_ensure('latest')
        .with_name('pe-postgresql') }
  it { is_expected.to contain_package('postgresql-contrib')
        .with_ensure('latest')
        .with_name('pe-postgresql-contrib') }
  it { is_expected.to contain_package('postgresql-server')
        .with_ensure('latest')
        .with_name('pe-postgresql-server') }

  it { is_expected.not_to have_a_resource('Exec[set console admin password]') }
end

describe 'database host' do
  context 'supported operating systems' do
    on_filtered_os(:redhat, :debian, :sles) do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:node) { 'database.rspec' }

        include_examples 'a base run on the database node'
        it { is_expected.to_not have_a_resource('Exec[Shutdown pe-postgresql before install]') }

        context 'when upgrading' do
          let(:context_facts) do
            {
              :pe_server_version => '2016.1.2',
            }
          end

          include_examples 'a base run on the database node'
          it { is_expected.to have_a_resource('Exec[Shutdown pe-postgresql before install]')
                .that_is_a_dependency_for_a_downstream('Package[postgresql-server]') }
        end
      end
    end
  end
end
