module PEInstall
  module DependencyMatchers
    class DependencyClass

      attr_accessor :resource_ref, :catalog, :ral, :resource, :graph,
        :upstream_whit, :downstream_whit,
        :failures, :tests


      def initialize(resource_ref)
        self.resource_ref = resource_ref
        self.failures = {
          :missing    => [],
          :type       => [],
          :upstream   => [],
          :downstream => [],
        }
        self.tests = {
          :upstream   => [],
          :downstream => [],
          :contains   => [],
        }
      end

      def matches?(catalogue)
        self.catalog = catalogue.call
        self.ral = catalog.to_ral
        self.resource = ral.resource(resource_ref)
        self.graph = ral.relationship_graph

        if resource && resource.type == :component
          self.upstream_whit = graph.vertices.find { |v| v.name == "admissible_#{resource}" }
          self.downstream_whit = graph.vertices.find { |v| v.name == "completed_#{resource}" }
        end

        passed = []
        passed << !resource.nil?
        passed << validate_and_munge_references
        if passed.all?
          passed << check_upstream_requirements
          passed << check_downstream_dependents
        end
        passed.all?
      end

      # The given *dependency_ref* is upstream from *resource_ref*.
      # The *dependency_ref* must execute before *resource_ref* can.
      #
      # *dependency_ref* ------> *resource_ref*
      #
      # (not necessarily a direct edge)
      #
      # @returns self for chaining
      def that_requires_an_upstream(*requirement_refs)
        tests[:upstream].concat(requirement_refs)
        self
      end
      alias_method :that_requires_upstream_resources, :that_requires_an_upstream

      # The given *dependent_ref* is downstream from *resource_ref*.
      # The *resource_ref* must be execute before *dependent_ref* can.
      #
      # *resource_ref* ------> *dependent_ref*
      #
      # (not necessarily a direct edge)
      #
      # @returns self for chaining
      def that_is_a_dependency_for_a_downstream(*dependent_refs)
        tests[:downstream].concat(dependent_refs)
        self
      end
      alias_method :that_is_a_dependency_for_downstream_resources, :that_is_a_dependency_for_a_downstream

      # Tests whether our resource_ref is contained by the given class or
      # defined_type component_ref.  If it is, we will find the component's
      # admissible whit in our upstream requirements, and the component's
      # completed whit in our downstream requirements.
      def that_is_contained_by(component_ref)
        tests[:contains] << component_ref
        tests[:upstream] << "admissible_#{component_ref}"
        tests[:downstream] << "completed_#{component_ref}"
        self
      end

      def description
        desc = "Contain #{resource_ref}"
        clauses = []
        if !tests[:upstream].empty?
          clauses << " with the following upstream requirements: #{tests[:upstream]}"
        end
        if !tests[:downstream].empty?
          clauses << " and" if !tests[:upstream].empty?
          clauses << " with the following downstream dependents: #{tests[:downstream]}"
        end
        desc + clauses.join
      end

      def failure_message
        failure_messages = ["expected that catalog would contain #{resource_ref}"]
        failure_messages << "  and that it would have these upstream requirements: #{tests[:upstream]}" if !tests[:upstream].empty?
        failure_messages << "  and that it would have these downstream dependents: #{tests[:downstream]}" if !tests[:downstream].empty?
        failure_messages << "But:\n"

        context = []

        if !resource
          failure_messages << "#{resource_ref} was missing."
        else
          failure_messages += failures[:type]

          if !tests[:upstream].empty?
            failures[:upstream].each do |ref|
              failure_messages << "#{ref} is not upstream"
            end
          end

          if !tests[:downstream].empty?
            failures[:downstream].each do |ref|
              failure_messages << "#{ref} is not downstream"
            end
          end

          failures[:missing].each do |ref|
            failure_messages << "#{ref} is missing from the catalog"
          end

          context = [
            "\n --- ",
            "Upstream requirements for #{upstream_node}:", get_upstream_requirement_refs,
            " --- ",
            "Downstream dependents for #{downstream_node}:", get_downstream_dependent_refs
          ].flatten
        end

        failure_messages.join("\n") +
          context.join("\n")
      end

      private

      def index
        @index ||= self.class.transform_to_refs(graph.vertices)
      end

      def _validate(references)
        references.each do |ref|
          failures[:missing] << ref if !index.include?(ref)
        end
      end

      # Checks that references exist in the catalog.
      #
      # Then modifies component type resources to reference the correct
      # starting or ending whit(s).
      #
      # Classes and defined_types are bracketed by two Puppet::Type::Whit
      # instances in the relationship_graph.  Classes and defined_types group
      # resources, they do no themselves take any action in the catalog.
      #
      # Class[foo] is entered through a whit admissible_Class[foo],
      # and exited through a whit completed_Class[foo].
      #
      def validate_and_munge_references
        # To test for requiring completion of an upstream class, we must look for
        # a reference to the completed whit for that class.
        tests[:upstream].map! do |ref|
          res = ral.resource(ref)
          (res && res.type == :component) ? "completed_#{ref}" : ref
        end
        _validate(tests[:upstream])

        # To test that a downstream class depends on our ref completing first,
        # we must look for a downstream reference to the admissible whit for
        # that class.
        tests[:downstream].map! do |ref|
          res = ral.resource(ref)
          (res && res.type == :component) ? "admissible_#{ref}" : ref
        end
        _validate(tests[:downstream])

        tests[:contains].each do |ref,res|
          res = ral.resource(ref)
          if res.type != :component
            failures[:type] << "WARNING: that_is_contained_by() expects to be given a class or defined_type reference, but was supplied with #{ref}"
          end
        end

        failures[:missing].empty? && failures[:type].empty?
      end

      def check(type, gold_refs)
        tests[type].each do |ref|
          found = gold_refs.include?(ref)
          failures[type] << ref if !found
          found
        end
        failures[type].empty?
      end

      def check_upstream_requirements
        check(:upstream, get_upstream_requirement_refs)
      end

      def get_upstream_requirement_refs
        self.class.transform_to_refs(get_upstream_requirements)
      end

      # This obtains the upstream resources that our resource_ref depends on.
      def get_upstream_requirements
        graph.dependencies(upstream_node)
      end

      def check_downstream_dependents
        check(:downstream, get_downstream_dependent_refs)
      end

      def get_downstream_dependent_refs
        self.class.transform_to_refs(get_downstream_dependents)
      end

      # This obtains the downstream resources that depend on our resource_ref.
      def get_downstream_dependents
        graph.dependents(downstream_node)
      end

      # This is either the resource, or if the resource is a component (a class or
      # defined type), then it is the admissible whit of the component that marks
      # the entry to the graph of resources it contains.
      def upstream_node
        resource.type == :component ? upstream_whit : resource
      end

      # This is either the resource, or if the resource is a component (a class or
      # defined type), then it is the completed whit of the component that marks
      # the exit from the graph of resources it contains.
      def downstream_node
        resource.type == :component ? downstream_whit : resource
      end

      public

      def self.transform_to_refs(resources)
        resources.map do |r|
          case r.type
          when :whit then r.name
          else r.to_s
          end
        end
      end
    end

    def print_resources(resource_list)
      pp DependencyClass.transform_to_refs(resource_list)
    end

    def have_a_resource(resource_ref)
      DependencyClass.new(resource_ref)
    end
  end
end
