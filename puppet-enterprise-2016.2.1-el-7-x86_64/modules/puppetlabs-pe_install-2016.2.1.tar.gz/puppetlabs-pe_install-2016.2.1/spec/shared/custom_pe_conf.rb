require 'fileutils'

module PEInstall
  module CustomPEConf

    # Allows you to run hosts tests with a temporarily generated node specific hieradata.
    # The given hieradata will be written to "spec/fixtures/hiera/hieradata/#{node}.yaml"
    # and if it matches the node name set for rspec-puppet will provide
    # parameters via spec/fixtures/hiera/hiera.yaml's configuration for any classes
    # included via the include('pe_install') in the default node configuration of
    # spec/fixtures/manifests/site.pp.
    #
    # This is a complex set of pre-requisites for the test, but it has the
    # advantage that the configuration is in the test, rather than a static
    # file magically included from the hieradata fixtures.
    def run_with_custom_pe_conf(node, hieradata, example)
      pe_conf = "spec/fixtures/hiera/hieradata/#{node}.yaml"
      File.open(pe_conf, "w") do |f|
        f.puts(hieradata)
      end
      example.run
    ensure
      FileUtils.rm(pe_conf, :force => true)
    end
  end
end
