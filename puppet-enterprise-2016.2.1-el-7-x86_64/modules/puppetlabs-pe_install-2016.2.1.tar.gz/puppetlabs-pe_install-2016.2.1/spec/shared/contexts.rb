RSpec.shared_context 'hosts', :hosts_context do |os, base_facts|
  let(:layout) { 'test' }
  let(:hiera_config) { 'spec/fixtures/hiera/hiera.yaml' }
  let(:platform_tag) { platform_tag_for(os, base_facts) }
  let(:aio_agent_build) { '1.5.0' }
  let(:fqdn) { node }
  let(:hostname) { node.sub(/\..*/,'') }
  let(:platform_class) { platform_tag.gsub('.','').gsub('-','_') }
  # Can override this in an example group to inject facts
  let(:context_facts) { {} }
  let(:facts) do
    base_facts.merge({
      :platform_tag    => platform_tag,
      :layout          => layout,
      :fqdn            => fqdn,
      :hostname        => hostname,
      :aio_agent_build => aio_agent_build,
    }).merge(context_facts)
  end

  before(:each) do
    local_aio_agent_build = aio_agent_build
    Puppet::Parser::Functions.newfunction(:pe_compiling_server_aio_build, :type => :rvalue) do |args|
      local_aio_agent_build
    end
    Puppet::Parser::Functions.newfunction(:pe_servername, :type => :rvalue) do |args|
      # servername is not set during puppet apply
      nil
    end
  end

  def platform_tag_for(os, facts)
    case os
    when /redhat/i
      then "el-#{facts[:os]['release']['major']}-#{facts[:architecture]}"
    when /ubuntu/i
      then "ubuntu-#{facts[:os]['release']['major']}-#{facts[:architecture]}"
    when /sles/i
      then "sles-#{facts[:os]['release']['major']}-#{facts[:architecture]}"
    else
      raise("Don't know how to create a platform_tag fact for os '#{os}'")
    end
  end
end
