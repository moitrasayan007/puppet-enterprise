module PEInstall
  module RspecPuppetFacts
    def on_filtered_os(*tags, &block)
      raise("No tags!") if tags.empty?
      filters = tags.map do |tag|
        case tag
        when :redhat then
          {
            'operatingsystem'        => 'RedHat',
            'operatingsystemrelease' => ['7'],
          }
        when :debian
          {
            'operatingsystem'        => 'Ubuntu',
            'operatingsystemrelease' => ['14.04'],
          }
        when :sles
          # SLES12 isn't in facterdb yet; we should put up a PR
          {
            'operatingsystem'        => 'SLES',
            'operatingsystemrelease' => ['11'],
          }
        else
          raise("Unknown supported_os filter tag '#{tag}'")
        end
      end
      on_supported_os({:supported_os => filters}).each(&block)
    end
  end
end
