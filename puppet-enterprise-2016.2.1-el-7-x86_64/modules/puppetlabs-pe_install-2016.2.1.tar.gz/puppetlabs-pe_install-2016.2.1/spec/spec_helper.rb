require 'puppetlabs_spec_helper/module_spec_helper'
require 'rspec-puppet-facts'
require 'matchers/shared_matchers'
require 'shared/contexts'
require 'shared/rspec_puppet_facts'
require 'shared/custom_pe_conf'

module PEInstall
  SPEC_BASE_DIR = File.expand_path(File.dirname(__FILE__))
end

RSpec.configure do |config|
  # Re-override the mock_with :mocha that is in
  # puppetlabs_spec_helper-1.1.1/lib/puppetlabs_spec_helper/puppet_spec_helper.rb:122
  config.mock_with :rspec
  config.extend(RspecPuppetFacts)
  config.extend(PEInstall::RspecPuppetFacts)
  config.include(PEInstall::DependencyMatchers)
  config.include(PEInstall::CustomPEConf)
  config.default_facts = {
    :pe_concat_basedir         => '/tmp/file',
    :platform_symlink_writable => true,
    # pe_build needs to be set to make `is_upgrade` work in params.pp
    :pe_build                  => '2016.2.0',
  }
  config.manifest = 'spec/fixtures/manifests/site.pp'
end
