require 'spec_helper'

describe 'pe_install::install' do
  let(:hiera_config) { 'spec/fixtures/hiera/hiera.yaml' }

  context 'supported operating systems' do
    on_supported_os.each do |os, facts|
      context "on #{os}", :os => os do
        let(:facts) do
          facts
        end

        it { is_expected.to compile.with_all_deps }
        it { is_expected.to contain_class('puppet_enterprise::profile::agent') }
        it { is_expected.to contain_service('puppet').with_ensure('running').with_enable(true) }
        it { is_expected.to contain_file('/opt/puppetlabs/bin/puppet-enterprise') }

        # All other profiles depend on pe_install::is_* variables which
        # aren't set since this is just an isolated 'include
        # pe_install::install' that is being tested
        #
        # See spec/hosts...
        #
        # TODO: although those values could be isolated using pre_condition()
        # (see spec/classes/prepare/certificates_spec.rb).  Alternately, we could
        # modify the manifests to explicitly pass all values the class needs.
      end
    end
  end
end
