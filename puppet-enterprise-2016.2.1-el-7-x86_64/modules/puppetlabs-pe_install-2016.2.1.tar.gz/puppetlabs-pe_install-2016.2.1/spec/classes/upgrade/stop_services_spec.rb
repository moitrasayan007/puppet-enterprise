require 'spec_helper'

describe 'pe_install::upgrade::stop_services' do
  let(:hiera_config) { 'spec/fixtures/hiera/hiera.yaml' }

  context 'supported operating systems' do
    on_supported_os.each do |os, base_facts|
      context "on #{os}", :os => os do
        let(:node) { 'master.rspec' }
        let(:layout) { 'mono' }
        let(:facts) do
          base_facts.merge(
            :layout => layout
          )
        end
        service_list = [
            'pe-nginx',
            'pe-console-services',
            'pe-puppetdb',
            'pe-postgresql',
            'pe-orchestration-services',
            'pe-puppetserver',
            'pe-activemq',
        ]

        it { is_expected.to compile.with_all_deps }

        context 'with a pe_install stub' do
          def pre_condition
            <<-PE_INSTALL_STUB
# Stub out the main classes so we only generate the various is_* test variables.
class pe_install::validate {}
class pe_install::prepare {}
class pe_install::install {}
include pe_install
            PE_INSTALL_STUB
          end

          describe 'upgrading to 2016.2.0' do
            ['2015.3.0','2016.1.2', ].each do |upgrade_ver|
              context "from #{upgrade_ver}" do
                let(:facts) do
                  base_facts.merge(
                    :layout => layout,
                    :pe_build => '2016.2.0',
                    :pe_server_version => upgrade_ver
                  )
                end

                service_list.each do |service|
                  it { is_expected.to contain_pe_install__stop_service("Stop #{service} service") }
                end
              end
            end

            # pe-orchestration-services didn't exist in 2015.2.3
            context 'from 2015.2.3' do
              let(:facts) do
                base_facts.merge(
                  :layout => layout,
                  :pe_build => '2016.2.0',
                  :pe_server_version => '2015.2.3'
                )
              end

              service_list.each do |service|
                next if service == 'pe-orchestration-services'
                it { is_expected.to contain_pe_install__stop_service("Stop #{service} service") }
              end

              it { is_expected.to_not contain_pe_install__stop_service("Stop pe-orchestration-services service") }
            end

            ['2016.2.0', '2016.2.0-rc0-40-g12345'].each do |upgrade_ver|
              context "from #{upgrade_ver}" do
                let(:facts) do
                  base_facts.merge(
                    :layout => layout,
                    :pe_build => '2016.2.0',
                    :pe_server_version => upgrade_ver,
                  )
                end

                service_list.each do |service|
                  it { is_expected.to_not contain_pe_install__stop_service("Stop #{service} service") }
                end
              end
            end
          end
        end
      end
    end
  end
end
