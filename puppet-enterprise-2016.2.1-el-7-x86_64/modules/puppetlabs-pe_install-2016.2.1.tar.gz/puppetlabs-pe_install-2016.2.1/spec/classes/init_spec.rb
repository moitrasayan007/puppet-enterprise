require 'spec_helper'

describe 'pe_install' do
  let(:hiera_config) { 'spec/fixtures/hiera/hiera.yaml' }
  context 'supported operating systems' do

    on_supported_os.each do |os, facts|
      context "on #{os}", :os => os do
        let(:facts) do
          facts
        end

        context "pe_install class without any parameters" do
          let(:params) {{ console_admin_password: 'puppetlabs' }}

          it { is_expected.to compile.with_all_deps }
          it { is_expected.to contain_class('pe_install::validate').that_comes_before('Class[pe_install::prepare]') }
          it { is_expected.to contain_class('pe_install::prepare').that_comes_before('Class[pe_install::install]') }
        end
      end
    end
  end
end
