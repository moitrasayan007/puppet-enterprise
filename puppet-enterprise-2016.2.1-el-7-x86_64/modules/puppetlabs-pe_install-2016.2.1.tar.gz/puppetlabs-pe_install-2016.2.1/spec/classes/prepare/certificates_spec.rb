require 'spec_helper'

describe 'pe_install::prepare::certificates' do
  let(:hiera_config) { 'spec/fixtures/hiera/hiera.yaml' }

  context 'supported operating systems' do
    on_supported_os.each do |os, facts|
      context "on #{os}", :os => os do
        let(:facts) do
          facts
        end

        it { is_expected.to compile.with_all_deps }

        context 'with a pe_install stub' do
          def pre_condition
            <<-PE_INSTALL_STUB
# Stub out the main classes so we only generate the various is_* test variables.
class pe_install::validate {}
class pe_install::prepare {}
class pe_install::install {}
include pe_install
            PE_INSTALL_STUB
          end

          let(:node) { 'master.rspec' }
          let(:layout) { 'split' }
          let(:facts) {
            facts.merge(
              :layout => layout
            )
          }

          it 'has puppet as a dnsaltname by default' do
            is_expected.to contain_exec('generate ca cert')
              .with_command("/opt/puppetlabs/puppet/bin/puppet cert --generate master.rspec --ca_name 'Puppet Enterprise CA' --dns_alt_names 'puppet'")
              .with_creates("/etc/puppetlabs/puppet/ssl/ca/signed/master.rspec.pem")
          end

          context 'set dnsaltnames' do
            let(:node) { 'masterwithalt.rspec' }
            let(:dnsaltnames) { "['some','other.net',#{node}]" }
            let(:pe_conf) do
              <<-HIERA
puppet_enterprise::certificate_authority_host: "#{node}"
puppet_enterprise::puppet_master_host: "#{node}"
puppet_enterprise::console_host: 'console.rspec'
puppet_enterprise::puppetdb_host: 'puppetdb.rspec'
puppet_enterprise::database_host: 'puppetdb.rspec'
puppet_enterprise::mcollective_middleware_hosts: ["#{node}"]
puppet_enterprise::pcp_broker_host: "#{node}"
pe_install::puppet_master_dnsaltnames: #{dnsaltnames}
              HIERA
            end

            around(:each) do |example|
              run_with_custom_pe_conf(node, pe_conf, example)
            end

            it 'includes dnsaltnames if passed' do
              is_expected.to contain_exec('generate ca cert')
                .with_command("/opt/puppetlabs/puppet/bin/puppet cert --generate #{node} --ca_name 'Puppet Enterprise CA' --dns_alt_names 'some,other.net,masterwithalt.rspec'")
                .with_creates("/etc/puppetlabs/puppet/ssl/ca/signed/masterwithalt.rspec.pem")
            end

            context 'as an empty list' do
              let(:node) { 'masterwithemptyalt.rspec' }
              let(:dnsaltnames) { "[]" }

              it 'skips dnsaltnames arg' do
                is_expected.to contain_exec('generate ca cert')
                  .with_command("/opt/puppetlabs/puppet/bin/puppet cert --generate #{node} --ca_name 'Puppet Enterprise CA'")
                  .with_creates("/etc/puppetlabs/puppet/ssl/ca/signed/masterwithemptyalt.rspec.pem")
              end
            end

            context 'with no value' do
              let(:node) { 'masterwithnoaltvalue.rspec' }
              let(:dnsaltnames) { }

              it 'defaults to puppet' do

                is_expected.to contain_exec('generate ca cert')
                  .with_command("/opt/puppetlabs/puppet/bin/puppet cert --generate #{node} --ca_name 'Puppet Enterprise CA' --dns_alt_names 'puppet'")
                  .with_creates("/etc/puppetlabs/puppet/ssl/ca/signed/masterwithnoaltvalue.rspec.pem")
              end
            end

            context 'with an empty string' do
              let(:node) { 'masterwithanemptystringalt.rspec' }
              let(:dnsaltnames) { '""' }

              it 'raises Type error' do
                expect { catalogue }.to raise_error(Puppet::PreformattedError, /expects an Array value, got String/)
              end
            end
          end
        end
      end
    end
  end
end
