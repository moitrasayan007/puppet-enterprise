require 'spec_helper'

RSpec.shared_examples 'non dynamic node groups' do

  it 'PE Certificate Authority node group' do
    is_expected.to contain_pe_node_group('PE Certificate Authority')
    .with_parent('PE Infrastructure')
    .with_pinned(['master.rspec'])
    .with_classes({'puppet_enterprise::profile::certificate_authority' => {}})
  end

  it 'PE ActiveMQ Broker node group' do
    is_expected.to contain_pe_node_group('PE ActiveMQ Broker')
    .with_parent('PE Infrastructure')
    .with_pinned(['master.rspec'])
  end

  it 'PE Orchestrator node group' do
    is_expected.to contain_pe_node_group('PE Orchestrator')
    .with_parent('PE Infrastructure')
    .with_pinned(['master.rspec'])
    .with_classes({'puppet_enterprise::profile::orchestrator' => {}})
  end

  it 'PE Console node group' do
    is_expected.to contain_pe_node_group('PE Console')
    .with_parent('PE Infrastructure')
    .with_pinned(['master.rspec'])
    .with_classes({
      'puppet_enterprise::profile::console' => {},
      'puppet_enterprise::license' => {},
    })
  end
  it 'PE PuppetDB node group' do
    is_expected.to contain_pe_node_group('PE PuppetDB')
    .with_parent('PE Infrastructure')
    .with_pinned(['master.rspec'])
    .with_classes({'puppet_enterprise::profile::puppetdb' => {}})
  end

  it 'PE MCollective node group' do
    is_expected.to contain_pe_node_group('PE MCollective')
    .with_parent('PE Infrastructure')
    .with_rule(['and', ['~', ['fact', 'aio_agent_version'], '.+']])
    .with_classes({'puppet_enterprise::profile::mcollective::agent' => {}})
  end

  it 'PE Agent node group' do
    is_expected.to contain_pe_node_group('PE Agent')
    .with_parent('PE Infrastructure')
    .with_rule(['and', ['~', ['fact', 'aio_agent_version'], '.+']])
    .with_classes({'puppet_enterprise::profile::agent' => {}})
  end
end

describe 'pe_install::install::classification' do
  context 'supported operating systems' do
    on_filtered_os(:redhat, :debian, :sles) do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:pre_condition) do
          <<-PE_INSTALL_STUB
# Stub out the main classes so we only generate the various is_* test variables.
class pe_install::validate {}
class pe_install::prepare {}
class pe_install::install {}
include pe_install
          PE_INSTALL_STUB
        end

        context 'default monolithic install' do
          let(:node) { 'master.rspec' }
          let(:layout) { 'mono' }
          let(:base_parameter_hash) do
            {
              'certificate_authority_host'   => 'master.rspec',
              'puppet_master_host'           => 'master.rspec',
              'console_host'                 => 'master.rspec',
              'puppetdb_host'                => 'master.rspec',
              'database_host'                => 'master.rspec',
              'mcollective_middleware_hosts' => ['master.rspec'],
              'pcp_broker_host'              => 'master.rspec',
            }
          end

          include_examples 'non dynamic node groups'

          it 'PE Infrastructure node group' do
            is_expected.to contain_pe_node_group('PE Infrastructure')
            .with_classes({'puppet_enterprise' => base_parameter_hash})
          end


          it 'PE Master node group' do
            is_expected.to contain_pe_node_group('PE Master')
            .with_parent('PE Infrastructure')
            .with_pinned(['master.rspec'])
            .with_classes({
              'pe_repo' => {},
              "pe_repo::platform::#{platform_class}" => {},
              'puppet_enterprise::profile::master' => {},
              'puppet_enterprise::profile::master::mcollective' => {},
              'puppet_enterprise::profile::mcollective::peadmin' => {},
            })
          end


        end

        context 'monolithic install with hiera overrides' do
          let(:node) { 'master.rspec' }
          let(:layout) { 'mono-classification-overrides' }
          let(:base_parameter_hash) do
            {
              'certificate_authority_host'   => 'master.rspec',
              'puppet_master_host'           => 'master.rspec',
              'console_host'                 => 'master.rspec',
              'puppetdb_host'                => 'master.rspec',
              'database_host'                => 'master.rspec',
              'mcollective_middleware_hosts' => ['spoke.rspec'],
              'pcp_broker_host'              => 'master.rspec',
            }
          end

          include_examples 'non dynamic node groups'

          it 'PE Infrastructure node group' do
            is_expected.to contain_pe_node_group('PE Infrastructure')
            .with_classes({
              'puppet_enterprise' =>
              base_parameter_hash.merge({
                'activity_database_name'     => 'activity-db-name',
                'activity_database_user'     => 'activity-db-user',
                'classifier_database_name'   => 'classifier-db-name',
                'classifier_database_user'   => 'classifier-db-user',
                'orchestrator_database_name' => 'orchestrator-db-name',
                'orchestrator_database_user' => 'orchestrator-db-user',
                'puppetdb_database_name'     => 'puppetdb-db-name',
                'puppetdb_database_user'     => 'puppetdb-db-user',
                'rbac_database_name'         => 'rbac-db-name',
                'rbac_database_user'         => 'rbac-db-user',
                'database_ssl'               => false,
                'database_cert_auth'         => false,
                'console_port'               => 123,
                'database_port'              => 456,
                'puppetdb_port'              => 789,
                'use_application_services'   => true,
              })})
          end

          it 'PE Master node group' do
            is_expected.to contain_pe_node_group('PE Master')
            .with_parent('PE Infrastructure')
            .with_pinned(['master.rspec'])
            .with_classes({
              'pe_repo' => {
                'base_path' => 'fake_tarball_server',
              },
              "pe_repo::platform::#{platform_class}" => {},
              'puppet_enterprise::profile::master' => {
                'check_for_updates'           => false,
                'code_manager_auto_configure' => false,
                'file_sync_enabled'           => false,
                'r10k_remote'                 => 'fake_remote',
                'r10k_private_key'            => 'fake_path',
                'use_legacy_auth_conf'        => false,
              },
              'puppet_enterprise::profile::master::mcollective' => {},
              'puppet_enterprise::profile::mcollective::peadmin' => {},
            })
          end
        end
      end
    end
  end
end
