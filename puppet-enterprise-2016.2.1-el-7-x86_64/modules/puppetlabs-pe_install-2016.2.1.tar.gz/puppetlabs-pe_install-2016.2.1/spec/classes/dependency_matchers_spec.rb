require 'spec_helper'

describe 'dependency_matchers' do
  it { is_expected.to have_a_resource('File[/one]') }
  it { is_expected.to have_a_resource('File[/one]').that_is_a_dependency_for_a_downstream('Service[one]') }
  it { is_expected.to have_a_resource('File[/one]').that_requires_an_upstream('Package[one]') }
  it { is_expected.to have_a_resource('Package[four]').that_requires_an_upstream('Class[One]') }
  it { is_expected.to have_a_resource('Service[one]').that_requires_an_upstream('Package[one]') }
  it { is_expected.to have_a_resource('Package[one]').that_is_a_dependency_for_a_downstream('Exec[/three]') }
  it { is_expected.to have_a_resource('Package[contained]').that_is_a_dependency_for_a_downstream('Exec[/three]') }
  it { is_expected.to have_a_resource('Class[Four]').that_requires_an_upstream('Class[One]') }
  it { is_expected.to have_a_resource('Class[One]').that_is_a_dependency_for_a_downstream('Class[Four]') }
  it { is_expected.to have_a_resource('Thing[c]').that_requires_an_upstream('Class[One]') }
  it { is_expected.to have_a_resource('Class[One]').that_is_a_dependency_for_a_downstream('Thing[c]') }
  it { is_expected.to have_a_resource('Package[two]').that_is_contained_by('Class[Two]') }
  it { is_expected.to have_a_resource('Exec[/something/a]').that_is_contained_by('Thing[a]') }
  it { is_expected.to have_a_resource('Class[Contained]').that_is_contained_by('Class[One]') }
  it { is_expected.to have_a_resource('Thing[b]').that_is_contained_by('Class[Two]') }

  it do
    is_expected.to(have_a_resource('Class[One]')
                   .that_is_a_dependency_for_a_downstream(
                      'Class[Four]',
                      'Class[Five]'
                   ))
    is_expected.to(have_a_resource('Class[One]')
                   .that_is_a_dependency_for_downstream_resources(
                      'Class[Four]',
                      'Class[Five]'
                   ))
  end

  it do
    is_expected.to(have_a_resource('Thing[c]')
                   .that_requires_an_upstream(
                      'Class[One]',
                      'Class[Contained]'
                   ))
    is_expected.to(have_a_resource('Thing[c]')
                   .that_requires_upstream_resources(
                      'Class[One]',
                      'Class[Contained]'
                   ))
  end

  context "testing failures" do
    it "describes expectation when failing" do
      expect { is_expected.to have_a_resource('Package[one]').that_requires_an_upstream('Package[four]') }.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /expected that catalog would contain Package\[one\].*and that it would have.*upstream.*Package\[four\]/m)
      )
    end

    it "provides context when failing" do
      expect { is_expected.to have_a_resource('Class[Five]').that_is_a_dependency_for_a_downstream('Package[one]') }.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /Upstream requirements for Class\[Five\].*Downstream dependents for Class\[Five\]/m)
      )
    end

    it "fails when an upstream requirement is not present" do
      expect { is_expected.to have_a_resource('Package[one]').that_requires_an_upstream('Package[four]') }.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /But.*Package\[four\] is not upstream/m)
      )
    end

    it "fails when a downstream dependent is not present" do
      expect { is_expected.to have_a_resource('Class[Five]').that_is_a_dependency_for_a_downstream('Package[one]') }.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /But.*Package\[one\] is not downstream/m)
      )
    end

    it "fails when not contained" do
      expect { is_expected.to have_a_resource('Package[included]').that_is_contained_by('Class[One]') }.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /But.*admissible_Class\[One\] is not upstream.*completed_Class\[One\] is not downstream/m)
      )
    end

    it "fails with a warning if you submit a simple resource where a class or defined type is expected" do
      expect { is_expected.to have_a_resource('Package[four]').that_is_contained_by('Package[one]') }.to raise_error(RSpec::Expectations::ExpectationNotMetError, /WARNING: that_is_contained_by.*expects to be given a class or defined_type/)
    end

    it "fails with a message about missing reference if resource does not exist in catalog" do
      expect { is_expected.to have_a_resource('Package[thatdoesnotexist]').that_is_contained_by('Package[one]') }.to raise_error(RSpec::Expectations::ExpectationNotMetError, /Package\[thatdoesnotexist\] was missing/)
    end

    it "fails with a message about missing reference if dependency does not exist in catalog" do
      expect { is_expected.to have_a_resource('Class[One]').that_requires_an_upstream('Package[thatdoesnotexist]') }.to raise_error(RSpec::Expectations::ExpectationNotMetError, /Package\[thatdoesnotexist\] is missing/)
    end

    it "lists all failed resources" do
      expect do
        is_expected.to(have_a_resource('Package[one]')
                       .that_requires_upstream_resources(
                          'Class[Three]',
                          'Class[Four]'
                       ))
      end.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /Three.*is not upstream.*Four.*is not upstream/m)
      )
    end

    it "lists all missing resources" do
      expect do
        is_expected.to(have_a_resource('Thing[c]')
                       .that_requires_upstream_resources(
                          'Class[notappearinginthistest]',
                          'Class[alsonotappearinginthistest]'
                       ))
      end.to(
        raise_error(RSpec::Expectations::ExpectationNotMetError,
                    /notappearinginthistest.*missing.*alsonotappearinginthistest.*missing/m)
      )
    end
  end
end
