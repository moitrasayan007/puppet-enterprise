require 'spec_helper'
require_relative '../../../lib/puppet/util/pe_node_groups'
require 'webmock/rspec'

describe Puppet::Util::Pe_node_groups do
  let(:classifier_config_path) {'/dev/null/classifier.yaml'}
  let(:classifier) {{ 'server' => 'stubserver', 'port' => '8080', 'prefix' => '/api'}}

  describe '#newobject' do
    context 'being passed classifier config' do
      it 'handles being passed only the server' do
        classifier = described_class.new('server')
        expect(classifier.config['server']).to eq('server')
        expect(classifier.config['port']).to eq(4433)
        expect(classifier.config['prefix']).to eq('/classifier-api')
      end
    end

    context 'when classifier.yaml exists' do
      context 'with a single classifier defined' do
        before do
          YAML.stubs(:load_file).with(classifier_config_path).returns(classifier)
          File.stubs(:exists?).with(classifier_config_path).returns(true)
        end

        it 'has a config' do
          expect(subject.config['server']).to eq('stubserver')
          expect(subject.config['port']).to eq('8080')
          expect(subject.config['prefix']).to eq('/api')
        end
      end

      context 'with multiple classifiers defined' do
        before do
          classifiers = [
            { 'server' => 'stubserver2', 'port' => '1010', 'prefix' => '/api2'},
            { 'server' => 'stubserver', 'port' => '8080', 'prefix' => '/api'},
          ]

          YAML.stubs(:load_file).with(classifier_config_path).returns(classifiers)
          File.stubs(:exists?).with(classifier_config_path).returns(true)
        end

        it 'uses the first defined classifier' do
          expect(subject.config['server']).to eq('stubserver2')
          expect(subject.config['port']).to eq('1010')
          expect(subject.config['prefix']).to eq('/api2')
        end
      end
    end

    context 'when using defaults' do
      before do
        File.stubs(:exists?).with(classifier_config_path).returns(false)
      end

      it 'uses the agents certname as the server' do
        expect(subject.config['server']).to eq(Puppet[:certname])
        expect(subject.config['port']).to eq(4433)
        expect(subject.config['prefix']).to eq('/classifier-api')
      end
    end

    context 'when the connection fails' do
      let(:api_url) { 'https://' + subject.config['server'] + ':' + subject.config['port'].to_s + subject.config['prefix'] + '/v1/test' }
      let(:api_request) { 'test' }
      let(:response_500) do
        { :status => 500, :body => 'Internal server error' }
      end
      let(:response_400) do
        { :status => 400, :body => 'Not found' }
      end
      let(:response_200) do
        { :status => 200, :body => '', :headers => {} }
      end

      before(:each) do
        # Use defaults
        File.stubs(:exists?).with(classifier_config_path).returns(false)
        Kernel.stubs(:sleep).with(10).returns(10)

        # Set SSL lookup to memory for puppets network pool
        # copied from https://github.com/puppetlabs/puppet/blob/master/spec/unit/network/http_pool_spec.rb
        Puppet::SSL::Key.indirection.terminus_class = :memory
        Puppet::SSL::CertificateRequest.indirection.terminus_class = :memory
      end

      it 'handles two 500 failures' do
        stub = stub_request(:get, api_url).
          to_return(response_500).times(2).
          to_return(response_200)
        expect { subject.send(:make_request, :get, api_request) }.not_to raise_error
        expect(stub).to have_been_made.times(3)
      end

      it 'handles two 400 failures' do
        stub = stub_request(:get, api_url).
          to_return(response_400).times(2).
          to_return(response_200)
        expect { subject.send(:make_request, :get, api_request) }.not_to raise_error
        expect(stub).to have_been_made.times(3)
      end

      it 'fails after five 400 errors' do
        stub = stub_request(:get, api_url).to_return(response_400)
        expect { subject.send(:make_request, :get, api_request) }.to raise_error /5 server error responses/
        expect(stub).to have_been_made.times(5)
      end

      it 'fails after five 500 errors' do
        stub = stub_request(:get, api_url).to_return(response_500)
        expect { subject.send(:make_request, :get, api_request) }.to raise_error /5 server error responses/
        expect(stub).to have_been_made.times(5)
      end

      it 'fails after one timeout' do
        stub = stub_request(:get, api_url).to_timeout
        expect { subject.send(:make_request, :get, api_request) }.to raise_error Timeout::Error
        expect(stub).to have_been_made.once
      end

      it 'fails on a 501 failure' do
        stub = stub_request(:get, api_url).
          to_return(:status => 501, :body => '{}').times(1)
        expect { subject.send(:make_request, :get, api_request) }.to raise_error /unexpected error/
        expect(stub).to have_been_made.once
      end

      it 'fails on a 404 failure' do
        stub = stub_request(:get, api_url).
          to_return(:status => 404, :body => '{}').times(1)
        expect { subject.send(:make_request, :get, api_request) }.to raise_error /unexpected error/
        expect(stub).to have_been_made.once
      end

      it 'has a customizable amount of failures' do
        allow(ENV).to receive(:[]).and_call_original
        allow(ENV).to receive(:[]).with("PE_NODE_GROUP_CLASSIFICATION_ATTEMPTS").and_return("2")
        stub = stub_request(:get, api_url).
          to_return(response_500).times(2)
        expect { subject.send(:make_request, :get, api_request) }.to raise_error /2 server error responses/
        expect(stub).to have_been_made.times(2)
      end
    end
  end
end
