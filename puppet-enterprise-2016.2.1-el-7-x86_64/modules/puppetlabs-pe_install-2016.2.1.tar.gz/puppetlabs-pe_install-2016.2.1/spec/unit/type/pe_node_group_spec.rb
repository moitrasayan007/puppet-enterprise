require 'spec_helper'

type_class = Puppet::Type.type(:pe_node_group)

describe type_class do
  let(:default_node_id) { '00000000-0000-4000-8000-000000000000' }
  let(:default_node_name) { 'All Nodes' }

  describe 'when validating attributes' do
    context 'name param' do
      it 'should require a name' do
        expect { type_class.new({}) }.to raise_error(Puppet::Error, 'Title or name must be provided')
      end

      it "should allow name with symbols, numbers, and whitespace" do
        expect { type_class.new(:name => 'crAzy inSane n0dE grou$ N@mE') }.to_not raise_error
      end
    end

    context 'id property' do
      it "should not allow an ID to be specified" do
        expect {
          type_class.new(:name => 'test node group', :id => '1234')
        }.to raise_error(Puppet::ResourceError, /ID is read-only/)
      end
    end

    context 'environment_trumps property' do
      it "should require boolean like values" do
        [:true, :false, :yes, :no, 'true', 'false', 'yes', 'no'].each do |val|
          ng = type_class.new(:name => 'stubname', :environment_trumps => val)
          expect { ng }.to_not raise_error
        end

        expect {
          type_class.new(:name => 'stubname', :environment_trumps => 'foo')
        }.to raise_error(Puppet::ResourceError, /expected a boolean value/)
      end
    end

    context 'create_only property' do
        let(:node_group) { type_class.new(:name => 'stubname', :parent => default_node_name, :create_only => true) }

        it 'should always be insync' do
          [:parent, :environment].each do |property|
            expect(node_group.property(property).insync?('out-of-sync')).to be_truthy
          end
        end
    end

    context 'parent property' do
      context 'by name' do
        let(:node_group) { type_class.new(:name => 'stubname', :parent => default_node_name) }

        it 'should allow identifying the parent by name' do
          expect { node_group }.to_not raise_error
        end

        it 'is insync' do
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_node_id)
          parent_prop.provider.class.stubs(:get_parent_name).returns(default_node_name)
          expect(parent_prop.insync?(default_node_name)).to be_truthy
        end
      end

      context 'by guid' do
        let(:node_group) { type_class.new(:name => 'stubname', :parent => default_node_id) }

        it 'should allow identifying the parent by guid' do
          expect { node_group }.to_not raise_error
        end

        it 'is insync' do
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_node_id)
          parent_prop.provider.class.stubs(:get_parent_name).returns(default_node_name)
          expect(parent_prop.insync?(default_node_name)).to be_truthy
        end
      end
    end

    context 'variables property' do
      it 'should require a hash' do
        ng = type_class.new(:name => 'stubname', :variables => {:foo => 'bar'})
        expect { ng }.to_not raise_error

        expect {
          type_class.new(:name => 'stubname', :variables => 'foo = bar')
        }.to raise_error(Puppet::ResourceError, /should be a Hash/)
      end
    end

    context 'rule property' do
    end

    context 'environment property' do
      it "should allow agent-specified environment" do
        ng = type_class.new(:name => 'stubname', :environment => 'agent-specified')
        expect { ng }.to_not raise_error
      end

      it "should allow environment name with an underscore" do
        ng = type_class.new(:name => 'stubname', :environment => 'environment_name')
        expect { ng }.to_not raise_error
      end

      it "should allow environment name with a number" do
        ng = type_class.new(:name => 'stubname', :environment => 'environment1')
        expect { ng }.to_not raise_error
      end

      it "should allow environment name without an underscore" do
        ng = type_class.new(:name => 'stubname', :environment => 'environment')
        expect { ng }.to_not raise_error
      end

      it "should not allow environment name with capital letters" do
        expect {
          type_class.new(:name => 'stubname', :environment => 'EnVironMent')
        }.to raise_error(/Invalid environment name/)
      end

      it "should not allow environment name with a dash" do
        expect {
          type_class.new(:name => 'stubname', :environment => 'not-a-valid-name')
        }.to raise_error(/Invalid environment name/)
      end
    end

    context 'classes property' do
      let(:node_group) { type_class.new(:name => 'stubname', :parent => default_node_name) }
      let(:default_classes) do
        {
          "some::class" => {
            "parameter" => "parameter value",
          }
        }
      end

      it 'should require a hash' do
        expect(type_class).to require_hash_for('classes')
      end

      context 'is insync with' do
        it 'no changes to classification' do
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_classes)
          expect(parent_prop.insync?(default_classes)).to be_truthy
        end

        it 'extra parameters exist on a group in classifier' do
          extra_params = {
            'some::class' => {
              'some_other_param' => 'some other value',
            }
          }.merge!(default_classes)
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_classes)
          expect(parent_prop.insync?(extra_params)).to be_truthy
        end

        it 'deleted classes' do
          deleted_params = {
            'some::class' => {
              'deleted_param' => :undef,
            }
          }.merge!(default_classes)
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(deleted_params)
          expect(parent_prop.insync?(default_classes)).to be_truthy
        end
      end

      context 'is not insync with' do
        it 'no classification' do
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_classes)
          expect(parent_prop.insync?({})).to be_falsey
        end

        it 'different classes' do
          different_classes = {
            'some::other::class' => {}
          }.merge!(default_classes)
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(default_classes)
          expect(parent_prop.insync?(different_classes)).to be_falsey
        end

        it 'undeleted parameters' do
          deleted_params = {
            'some::class' => {
              'parameter' => :undef,
            },
          }
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(deleted_params)
          expect(parent_prop.insync?(default_classes)).to be_falsey
        end

        it 'undeleted classes' do
          deleted_params = {
            'some::class' => :undef,
          }
          parent_prop = node_group.property(:parent)
          parent_prop.stubs(:should).returns(deleted_params)
          expect(parent_prop.insync?(default_classes)).to be_falsey
        end
      end
    end

    context 'refresh_classes param' do
      it "should require boolean like values" do
        [:true, :false, :yes, :no, 'true', 'false', 'yes', 'no'].each do |val|
          ng = type_class.new(:name => 'stubname', :refresh_classes => val)
          expect { ng }.to_not raise_error
        end

        expect {
          type_class.new(:name => 'stubname', :refresh_classes => 'foo')
        }.to raise_error(Puppet::ResourceError, /Invalid value/)
      end
    end

    context 'pinned param' do
      context 'is == :absent' do
        let(:is) do
          :absent
        end
        let(:prop) do
          ng.property(:pinned)
        end

        context 'should == an empty array' do
          let(:ng) do
            type_class.new(:name => 'stubname', :pinned => [])
          end

          it "should not throw an error when passed an array" do
            expect { prop }.to_not raise_error
          end

          it "is not insync" do
            expect(prop.insync?(is)).to be true
          end
        end

        context 'should == an array' do
          let(:ng) do
            type_class.new(:name => 'stubname', :pinned => ['foo', 'bar'])
          end

          it "should not throw an error when passed an array" do
            expect { prop }.to_not raise_error
          end

          it "is not insync" do
            expect(prop.insync?(is)).to be false
          end
        end
      end
    end
  end
end
