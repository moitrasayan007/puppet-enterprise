require 'spec_helper'
require 'webmock/rspec'
require 'puppet/network/http_pool'

describe Puppet::Type.type(:pe_node_group).provider(:ruby) do

  # Helper method to generate a pe_node_group resource based on default params
  def generate_resource(parameters = {})
    parameters[:name]               ||= 'stub_name'
    parameters[:environment_trumps] ||= false
    parameters[:parent]             ||= 'All Nodes'
    parameters[:rule]               ||= ['or', ['=', 'name', 'master.puppetlabs.vm']]
    parameters[:environment]        ||= 'stubenvironment'
    parameters[:classes]            ||= {'puppet_enterprise::profile::amq::broker' => {}}
    parameters[:variables]          ||= { :stubkey  => :stubvalue, :stubkey2 => :stubvalue2, }

    Puppet::Type.type(:pe_node_group).new(parameters)
  end

  let(:resource) { generate_resource }
  let(:provider) { described_class.new(resource) }

  let(:ng_1_params) do
    {:name => 'stub node group 1'}
  end
  let(:ng_2_params) do
    {:name => 'stub node group 2'}
  end
  let(:ng_3_params) do
    {:name => 'stub node group 3'}
  end
  let(:stub_ng_1) { generate_resource(ng_1_params) }
  let(:stub_ng_2) { generate_resource(ng_2_params) }
  let(:stub_ng_3) { generate_resource(ng_3_params) }

  let(:default_ng_id) { '00000000-0000-4000-8000-000000000000' }
  let(:stub_id) { 'a39c310d-a61b-40a4-8283-2b6416fcaee6' }
  let(:classifier_yaml_path) { '/dev/null/classifier.yaml' }
  let(:stub_server) { 'stubserver' }
  let(:stub_port) { 8080 }
  let(:api_url) { "https://#{stub_server}:#{stub_port}/classifier-api/v1/groups" }
  let(:get_groups_response) do
    <<-EOS
  [
    {
        "classes": {},
        "environment": "production",
        "environment_trumps": false,
        "id": "00000000-0000-4000-8000-000000000000",
        "name": "All Nodes",
        "parent": "00000000-0000-4000-8000-000000000000",
        "rule": [
            "and",
            [
                "~",
                "name",
                ".*"
            ]
        ],
        "variables": {}
    }
  ]
    EOS
  end

  before :each do
    File.stubs(:exists?).with(classifier_yaml_path).returns(true)
    YAML.stubs(:load_file).with(classifier_yaml_path)
    .returns({'server' => stub_server, 'port' => stub_port})

    # Set SSL lookup to memory for puppets network pool
    # copied from https://github.com/puppetlabs/puppet/blob/master/spec/unit/network/http_pool_spec.rb
    Puppet::SSL::Key.indirection.terminus_class = :memory
    Puppet::SSL::CertificateRequest.indirection.terminus_class = :memory
    stub_request(:get, api_url).to_return(:status => 200, :body => get_groups_response)
  end

  describe ".instances" do
    it "returns each node group" do
      res = provider.class.instances
      expect(res.count).to be(1)
      expect(res[0]).to be_a(Puppet::Provider)
    end
  end

  describe '.get_pinned_nodes_from_rule' do
    context 'pinned nodes and facts' do
      it 'returns the pinned node' do
        rule = ['or', ['and', ['not', ['=', ['fact', 'datacenter'], 'dc1']], ['=', ['fact', 'datacenter'], 'dc2']], ['=', 'name', 'pinned.example.vm']]
        expect(provider.class.get_pinned_nodes_from_rule(rule)).to eq(['pinned.example.vm'])
      end

      it 'handles fact name' do
        rule = ['or', ['and', ['=', ['fact', 'name'], 'fact.pinned.example.vm']], ['=', 'name', 'pinned.example.vm']]
        expect(provider.class.get_pinned_nodes_from_rule(rule)).to eq(['pinned.example.vm'])
      end
    end

    context 'pinned nodes only' do
      it 'handles 1 pinned node' do
        rule = ['or', ['=', 'name', 'pinned.example.vm']]
        expect(provider.class.get_pinned_nodes_from_rule(rule)).to eq(['pinned.example.vm'])
      end

      it 'handles multiple pinned nodes' do
        rule = ['or', ['=', 'name', 'pinned.example.vm'], ['=', 'name', 'also.pinned.example.vm']]
        expect(provider.class.get_pinned_nodes_from_rule(rule)).to eq(['pinned.example.vm', 'also.pinned.example.vm'])
      end
    end

    context 'facts only' do
      it 'returns an empty array' do
        rule = ['and', ['not', ['=', 'name', 'wef']], ['=', 'name', 'bar'], ['not', ['=', ['fact', 'fads'], 'gfg']], ['=', ['fact', 'asd'], 'asd']]
        expect(provider.class.get_pinned_nodes_from_rule(rule)).to eq([])
      end
    end
  end

  describe '.prefetch' do
    after(:each) do
      provider.class.instance_variable_set(:@classifier, nil)
    end

    context 'when multiple resources' do
      context 'pass different parameters' do
        describe 'refresh_classes' do
          it 'still calls update_classes' do
            ng_1_params[:refresh_classes] = true
            ng_2_params[:refresh_classes] = false
            resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

            classifier = double(Puppet::Util::Pe_node_groups)
            allow(provider.class).to receive(:init_pe_node_groups) { classifier }
            allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }
            expect(classifier).to receive(:refresh_classes).once.and_return(true)

            provider.class.prefetch(resources)
          end
        end

        [:server, :port, :prefix].each do |param|
          describe "#{param.to_s} parameter" do
            it 'raises an error if different' do
              ng_1_params[param] = 'foo'
              ng_3_params[param] = 'bar'
              resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2, stub_ng_3[:name] => stub_ng_3 }

              expect { provider.class.prefetch(resources) }.to raise_error(Puppet::Error, /different server/)
            end
          end
        end
      end
    end

    context 'pass the same parameters' do
      describe 'refresh_classes' do
        it 'only calls update_class once' do
          ng_1_params[:refresh_classes] = true
          ng_2_params[:refresh_classes] = true
          resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

          classifier = double(Puppet::Util::Pe_node_groups)
          allow(provider.class).to receive(:init_pe_node_groups) { classifier }
          allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }
          expect(classifier).to receive(:refresh_classes).once.and_return(true)

          provider.class.prefetch(resources)
        end

        it 'does not call update_class if false' do
          ng_1_params[:refresh_classes] = false
          ng_2_params[:refresh_classes] = false
          resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

          classifier = double(Puppet::Util::Pe_node_groups)
          allow(provider.class).to receive(:init_pe_node_groups) { classifier }
          allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }
          expect(classifier).to_not receive(:refresh_classes)

          provider.class.prefetch(resources)
        end
      end

      describe 'server' do
        it 'uses it' do
          ng_1_params[:server] = 'foo'
          resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

          classifier = double(Puppet::Util::Pe_node_groups)
          expect(provider.class).to receive(:init_pe_node_groups).with('foo', nil, nil).and_return(classifier)
          allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }

          provider.class.prefetch(resources)
        end
      end

      describe 'port' do
        it 'uses it' do
          ng_1_params[:port] = 1234
          resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

          classifier = double(Puppet::Util::Pe_node_groups)
          expect(provider.class).to receive(:init_pe_node_groups).with(nil, 1234, nil).and_return(classifier)
          allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }

          provider.class.prefetch(resources)
        end
      end

      describe 'prefix' do
        it 'uses it' do
          ng_2_params[:prefix] = 'api'
          resources = { stub_ng_1[:name] => stub_ng_1, stub_ng_2[:name] => stub_ng_2 }

          classifier = double(Puppet::Util::Pe_node_groups)
          expect(provider.class).to receive(:init_pe_node_groups).with(nil, nil, 'api').and_return(classifier)
          allow(provider.class).to receive(:instances) { [stub_ng_1.provider, stub_ng_2.provider] }

          provider.class.prefetch(resources)
        end
      end
    end
  end

  describe "#create" do
    before(:each) do
      headers = {
        :location => "/classifier-api/v1/groups/#{stub_id}"
      }
      stub_request(:post, api_url).to_return(:status => 303, :headers => headers)
    end

    it 'only sends allowed api keys' do
      provider.resource = generate_resource(:server => stub_server)
      provider.create
      assert_requested(:post, api_url) do |req|
        body = JSON.parse(req.body)
        body.has_key?('server') == false
      end
    end

    it 'converts parent property from string to guid' do
      provider.create
      assert_requested(:post, api_url) do |req|
        body = JSON.parse(req.body)
        body['parent'] == default_ng_id
      end
    end

    it 'assigns the resource the generated ID' do
      provider.create
      expect(provider.id).to eq(stub_id)
      expect(a_request(:post, api_url)).to have_been_made.once
    end

    context 'with pinned node' do
      let(:resource) { generate_resource(:rule => nil, :pinned => 'master.puppetlabs.vm') }
      let(:pin_api_url) { "https://#{stub_server}:#{stub_port}/classifier-api/v1/groups/#{stub_id}/pin" }

      it 'generates node group and pins node' do
        stub_request(:post, pin_api_url)
          .with(:body => "{\"nodes\":[\"master.puppetlabs.vm\"]}")
          .to_return(:status => 204)

        provider.create

        expect(a_request(:post, api_url)).to have_been_made.once
        expect(a_request(:post, pin_api_url)).to have_been_made.once
      end
    end
  end

  describe "#destroy" do
    it "deletes the node group" do
      stub_url = "#{api_url}/#{stub_id}"
      stub_request(:delete, stub_url).to_return(:status => 204)
      provider.id = stub_id
      provider.destroy
      assert_requested(:delete, stub_url)
    end
  end

  describe "#flush" do
    let(:resource) { generate_resource(:environment => 'newenvironment') }
    let(:stub_url) { "#{api_url}/#{stub_id}" }

    before(:each) do
      stub_request(:post, stub_url).to_return(:status => 200)
      provider.id = stub_id
    end

    it "updates the node group" do
      provider.environment = 'oldenvironment'
      resource.provider = provider
      resource.parameters[:environment].sync

      provider.flush

      assert_requested(:post, stub_url) do |req|
        body = JSON.parse(req.body)
        body['environment'] == 'newenvironment'
      end
    end

    context 'with pinned node' do
      let(:resource) { generate_resource(:rule => nil, :pinned => 'master.puppetlabs.vm') }
      let(:pin_api_url) { "https://#{stub_server}:#{stub_port}/classifier-api/v1/groups/#{stub_id}/pin" }

      it 'generates node group and pins node' do
        stub_request(:post, pin_api_url)
          .with(:body => "{\"nodes\":[\"other.puppetlabs.vm\"]}")
          .to_return(:status => 204)

        provider.pinned = 'other.puppetlabs.vm'
        provider.flush

        expect(a_request(:post, stub_url)).to have_been_made.once
        expect(a_request(:post, pin_api_url)).to have_been_made.once
      end
    end
  end
end
