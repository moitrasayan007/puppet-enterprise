require 'spec_helper'

describe :platform_tag_to_pe_repo_class do
  let(:scope) { PuppetlabsSpec::PuppetInternals.scope }

  it "should exist" do
    expect(Puppet::Parser::Functions.function("platform_tag_to_pe_repo_class")).to eq("function_platform_tag_to_pe_repo_class")
  end

  it "should raise a ParseError if there is less than 1 arguments" do
    expect { scope.function_platform_tag_to_pe_repo_class([]) }.to( raise_error(Puppet::ParseError) )
  end

  it "should raise a ParseError if there is more than 1 arguments" do
    expect { scope.function_platform_tag_to_pe_repo_class(['argument1','argument2']) }.to( raise_error(Puppet::ParseError) )
  end

  describe "on supported operating systems" do
    context "ubuntu" do
      it "should return the proper class for 12.04" do
        expect { scope.function_platform_tag_to_pe_repo_class(['ubuntu-12.04-amd64']).to eq('ubuntu_1204_amd64') }
      end

      it "should return the proper class for 14.04" do
        expect { scope.function_platform_tag_to_pe_repo_class(['ubuntu-14.04-amd64']).to eq('ubuntu_1404_amd64') }
      end
    end

    context "el" do
      it "should return the proper class for 6" do
        expect { scope.function_platform_tag_to_pe_repo_class(['el-6-x86_64']).to eq('el_6_x86_64') }
      end

      it "should return the proper class for 7" do
        expect { scope.function_platform_tag_to_pe_repo_class(['el-7-x86_64']).to eq('el_7_x86_64') }
      end
    end

    context "SLES" do
      it "should return the proper class for 11" do
        expect { scope.function_platform_tag_to_pe_repo_class(['sles-11-x86_64']).to eq('sles_11_x86_64') }
      end

      it "should return the proper class for 12" do
        expect { scope.function_platform_tag_to_pe_repo_class(['sles-12-x86_64']).to eq('sles_12_x86_64') }
      end
    end
  end

end
