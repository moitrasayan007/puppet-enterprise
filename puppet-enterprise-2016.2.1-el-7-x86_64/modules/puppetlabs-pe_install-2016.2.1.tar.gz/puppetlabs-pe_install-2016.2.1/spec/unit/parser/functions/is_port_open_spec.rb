require 'spec_helper'

describe :is_port_open do
  let(:scope) { PuppetlabsSpec::PuppetInternals.scope }

  it "exists" do
    expect(Puppet::Parser::Functions.function("is_port_open")).to eq("function_is_port_open")
  end

  it "raises a ParseError if there are less than 2 arguments" do
    expect { scope.function_is_port_open([]) }.to  raise_error(ArgumentError, /Wrong number of arguments.*0 for 2/)
  end

  it "raises a ParseError if there are more than 2 arguments" do
    expect { scope.function_is_port_open(['foo', 'bar', 'baz']) }.to raise_error(ArgumentError, /Wrong number of arguments.*3 for 2/)
  end

  it "returns true when port is open" do
    socket = double('TCPSocket').as_null_object
    expect(TCPSocket).to receive(:new).with('puppetdb.rspec', 5432).and_return(socket)

    expect(scope.function_is_port_open(['puppetdb.rspec', 5432])).to eq( true )
  end

  [
    Errno::ECONNREFUSED,
    Errno::EHOSTUNREACH,
    [SystemCallError, -1]
  ].each do |err|
    it "returns false when port is closed and raises an #{err}" do
      expect(TCPSocket).to receive(:new).with('puppetdb.rspec', 5432).and_raise(*err)
      expect(scope.function_is_port_open(['puppetdb.rspec', 5432])).to eq( false )
    end
  end

  context "with logging" do
    let(:logs) { [] }

    around(:each) do |example|
      Puppet::Util::Log.with_destination(Puppet::Test::LogCollector.new(logs)) do
        example.run
      end
    end

    before(:each) do
      Puppet::Util::Log.level = :info
    end

    it "returns false and logs unexpected SystemCallErrors to info" do
      expect(TCPSocket).to receive(:new).with('puppetdb.rspec', 5432).and_raise(Errno::EHOSTDOWN)

      expect(scope.function_is_port_open(['puppetdb.rspec', 5432])).to eq( false )
      expect(logs.map { |l| l.message }).to include(/While testing for an open port at puppetdb.rspec:5432, received Errno::EHOSTDOWN 'Host is down' error/)
    end

    it "returns false and logs when handling resolution errors" do
      expect(scope.function_is_port_open(['this.does.not.resolve', 5432])).to eq( false )
      expect(logs.map { |l| l.message }).to include(/While testing for an open port at this\.does\.not\.resolve:5432, received SocketError 'getaddrinfo/)
    end
  end

  it "returns false when the connection attempt times out" do
    expect(TCPSocket).to receive(:new) {
      sleep 15
    }
    expect(scope.function_is_port_open(['puppetdb.rspec', 5432])).to eq(false)
  end

  it "raises errors that are not SystemCallError" do
    expect(TCPSocket).to receive(:new).and_raise(RuntimeError, 'oops')
    expect { scope.function_is_port_open(['puppetdb.rspec', 5432]) }.to raise_error(RuntimeError, 'oops')
  end
end
