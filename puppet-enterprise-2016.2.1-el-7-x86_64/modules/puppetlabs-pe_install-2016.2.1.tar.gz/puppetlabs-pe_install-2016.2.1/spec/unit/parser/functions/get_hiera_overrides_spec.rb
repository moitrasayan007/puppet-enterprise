require 'spec_helper'

describe :get_hiera_overrides, :type => :puppet_function do
  context 'supported operating systems' do
    on_filtered_os(:redhat) do |os, base_facts|
      context "on #{os}", :os => os do
        include_context('hosts', os, base_facts)

        let(:node) { 'test' }
        let(:layout) { 'split' }

        it 'exists' do
          expect(Puppet::Parser::Functions.function('get_hiera_overrides')).to eq('function_get_hiera_overrides')
        end

        context 'error handling' do
          it { is_expected.to run.and_raise_error(ArgumentError) }
          it { is_expected.to run.with_params('name', ['param'], 'foo').and_raise_error(ArgumentError) }
          it { is_expected.to run.with_params(1, ['param']).and_raise_error(Puppet::ParseError, /must be of type String/) }
          it { is_expected.to run.with_params('namespace', 'param').and_raise_error(Puppet::ParseError, /must be of type Array/) }
        end

        context 'hiera lookups' do
          it 'returns all values' do
            is_expected.to run.with_params('puppet_enterprise', ['puppetdb_host', 'doesnt_exist', 'console_host'])
              .and_return({
                'puppetdb_host' => 'puppetdb.rspec',
                'console_host'  => 'console.rspec',
              })
          end

          it 'returns an empty has if no overrides' do
            is_expected.to run.with_params('puppet_enterprise', ['doesnt_exist']).and_return({})
          end
        end
      end
    end
  end
end
