##2015-11-13 - Release 0.1.0
###Summary

This is the initial release of the module.

####Features
* Manages the `auth.conf` file using authorization rules written as Puppet resources.
