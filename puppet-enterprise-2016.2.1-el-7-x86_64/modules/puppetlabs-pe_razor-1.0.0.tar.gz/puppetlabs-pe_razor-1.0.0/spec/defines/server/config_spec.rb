require 'spec_helper'

describe 'pe_razor::server::config' do
  before :each do
    @facter_facts = {
      'operatingsystem'           => 'RedHat',
      'operatingsystemmajrelease' => '6',
      'pe_razor_server_version'   => '1.0.1.1',
    }
    @params = {
      'server_http_port'          => '8150',
      'server_https_port'         => '8151',
      'protect_new_nodes'         => false,
      'repo_store_root'           => '/some/path',
      'task_path'                 => '/some/task_path',
      'broker_path'               => '/some/broker/path',
      'hook_path'                 => '/some/hook/path',
      'hook_execution_path'       => '/some/hook/execution/path',
      'match_nodes_on'            => ['mac'],
      'pe_tarball_base_url'       => nil,
      'server_http_port'          => 8950,
      'server_https_port'         => 8951,
      'microkernel_url'           => nil,
      'microkernel_debug_level'   => 'debug',
      'microkernel_kernel_args'   => '',
      'microkernel_extension_zip' => '/some/extension.zip',
      'database_url'              => 'jdbc:postgresql:razor?user=razor&password=strongPassword1234',
      'auth_enabled'              => false,
      'auth_config'               => '/some/shiro.ini',
      'secure_api'                => true,
      'checkin_interval'          => 15,
      'facts_blacklist'           => [],
      'facts_match_on'            => [],
      'api_config_blacklist'      => [],
      'auth_allow_localhost'      => false,
      'store_hook_input'          => false,
      'store_hook_output'         => false,
    }
  end

  let(:title) { 'razor' }
  let(:params) { @params }
  let(:facts) { @facter_facts }

  context 'with valid parameters' do
    it { should contain_file('/etc/sysconfig/pe-razor-server').with(
      :ensure => 'file',
      :owner => 'root',
      :mode => '0644',
    ).with_content(<<EOF) }
# Managed by pe_razor
# The location of the razor config files
RAZOR_CONFIG=/etc/puppetlabs/razor-server/config-defaults.yaml
# The ports that the razor-server service should listen on
RAZOR_HTTP_PORT=8950
RAZOR_HTTPS_PORT=8951
# Kept for backwards-compatibility during upgrade from 1.0.1.0
HTTP_PORT=8950
HTTPS_PORT=8951
EOF
    it { should contain_file('/opt/puppetlabs/server/data/razor-server').with(
      :ensure => 'directory',
      :owner  => 'root'
    ) }
    it { should contain_file('/etc/puppetlabs/razor-server').with(
      :ensure => 'directory',
      :owner  => 'pe-razor',
      :mode   => '0640',
    ) }
    it { should contain_file('/opt/puppetlabs/server/data/razor-server/repo').with(
      :ensure => 'directory',
      :owner  => 'pe-razor',
      :mode   => '0755',
    ) }
    it { should contain_file('/etc/puppetlabs/razor-server/config-defaults.yaml').with_content(/database_url.*password=strongPassword1234'/) }
    it { should contain_file('/etc/puppetlabs/razor-server/shiro.ini') }
  end
end
