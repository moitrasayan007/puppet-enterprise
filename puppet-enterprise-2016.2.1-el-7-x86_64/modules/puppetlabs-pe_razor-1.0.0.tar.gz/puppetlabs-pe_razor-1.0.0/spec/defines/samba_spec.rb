require 'spec_helper'

describe 'pe_razor::samba' do
  let(:title) { 'razor' }

  context 'with valid parameters' do
    it { should contain_pe_razor__samba__server('razor') }
    it { should contain_pe_razor__samba__share('razor') }
    it { should contain_pe_razor__samba__service('razor')}
  end
end
