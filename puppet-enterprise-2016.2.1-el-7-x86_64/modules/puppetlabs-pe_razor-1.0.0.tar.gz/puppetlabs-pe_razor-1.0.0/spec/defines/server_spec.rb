require 'spec_helper'

describe 'pe_razor::server' do
  before :each do
    @facter_facts = {
        'operatingsystem'           => 'RedHat',
        'operatingsystemmajrelease' => '6',
        'pe_razor_server_version'   => '1.0.0.70',
    }
    @params = {
        'server_http_port'          => '8150',
        'server_https_port'         => '8151',
        'protect_new_nodes'         => false,
        'repo_store_root'           => '/some/path',
        'task_path'                 => '/some/task_path',
        'broker_path'               => '/some/broker/path',
        'hook_path'                 => '/some/hook/path',
        'hook_execution_path'       => '/some/hook/execution/path',
        'match_nodes_on'            => ['mac'],
        'dbpassword'                => 'razor',
        'pe_tarball_base_url'       => nil,
        'server_http_port'          => 8950,
        'server_https_port'         => 8951,
        'microkernel_url'           => nil,
        'microkernel_debug_level'   => 'debug',
        'microkernel_kernel_args'   => '',
        'microkernel_extension_zip' => '/some/extension.zip',
        'database_url'              => 'jdbc:postgresql:razor?user=razor&password=strongPassword1234',
        'auth_enabled'              => false,
        'auth_config'               => '/some/shiro.ini',
        'secure_api'                => true,
        'checkin_interval'          => 15,
        'facts_blacklist'           => [],
        'facts_match_on'            => [],
        'api_config_blacklist'      => ['database_url'],
        'enable_windows_smb'        => true,
        'auth_allow_localhost'      => false,
        'store_hook_input'          => false,
        'store_hook_output'         => false,
    }
  end

  let(:title) { 'razor' }
  let(:params) { @params }
  let(:facts) { @facter_facts }

  context 'with valid parameters' do
    it { should contain_pe_razor__server__config('razor').that_requires('Package[pe-razor-server]') }
  end
end
