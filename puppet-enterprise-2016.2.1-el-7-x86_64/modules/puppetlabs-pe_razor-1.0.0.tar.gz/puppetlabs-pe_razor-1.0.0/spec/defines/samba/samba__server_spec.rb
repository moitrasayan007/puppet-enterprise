require 'spec_helper'

describe 'pe_razor::samba::server' do
  let(:title) { 'razor' }
  let(:facts) {{ :osfamily => 'Debian' }}

  it { should contain_pe_razor__samba__install('razor') }
  it { should contain_pe_razor__samba__config('razor') }
  it { should contain_pe_razor__samba__service('razor') }

  it { should contain_pe_razor__samba__option('interfaces') }
  it { should contain_pe_razor__samba__option('bind interfaces only') }
  it { should contain_pe_razor__samba__option('security') }
  it { should contain_pe_razor__samba__option('server string') }
  it { should contain_pe_razor__samba__option('unix password sync') }
  it { should contain_pe_razor__samba__option('workgroup') }
  it { should contain_pe_razor__samba__option('socket options') }
  it { should contain_pe_razor__samba__option('deadtime') }
  it { should contain_pe_razor__samba__option('keepalive') }
  it { should contain_pe_razor__samba__option('load printers') }
  it { should contain_pe_razor__samba__option('printing') }
  it { should contain_pe_razor__samba__option('printcap name') }
  it { should contain_pe_razor__samba__option('disable spoolss') }

  context 'with hiera shares hash' do
    let(:params) {{
        'shares' => {
          'testShare' => {
            'path' => '/path/to/some/share',
            'browsable' => true,
            'writable' => true,
            'guest_ok' => true,
            'guest_only' => true,
         },
         'testShare2' => {
            'path' => '/some/other/path'
         }
       }
    }}
    it { 
      should contain_pe_razor__samba__share( 'testShare' ).with({
          'path' => '/path/to/some/share',
          'browsable' => true,
          'writable' => true,
          'guest_ok' => true,
          'guest_only' => true,
      })
    }
    it { should contain_pe_razor__samba__share( 'testShare2' ).with_path('/some/other/path') }
  end

end
