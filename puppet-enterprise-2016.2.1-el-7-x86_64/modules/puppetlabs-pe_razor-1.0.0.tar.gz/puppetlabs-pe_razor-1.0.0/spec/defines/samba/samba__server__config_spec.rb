require 'spec_helper'

describe 'pe_razor::samba::config' do
  context "on a Debian OS" do
    let(:title) { 'razor' }
    let(:params) { {} }
    let( :facts ) { { :osfamily => 'Debian' } }

    it { should contain_file('/etc/samba/smb.conf').with_owner('root') }
  end
end

