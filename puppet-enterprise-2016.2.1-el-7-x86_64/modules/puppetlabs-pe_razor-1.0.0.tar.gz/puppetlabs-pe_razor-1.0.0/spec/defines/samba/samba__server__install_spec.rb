require 'spec_helper'

describe 'pe_razor::samba::install' do
  context "on a Debian OS" do
    let(:title) { 'razor' }
    let(:facts) {{ :osfamily => 'Debian' }}
    it { should contain_package('samba') }
  end
end

